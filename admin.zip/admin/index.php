<?php require 'pdoCV.php' ?> 
<?php require '../inc/head.inc.php'; ?>
<?php require 'top.php'; ?>
<?php require 'nav.html'; ?>
           
<?php // require '../admin/utilisateur.php'; ?>

        </body>
    </html>
